This application is a sample of the library GLIP-Lib (OpenGL Image Processing Library).
You can redistribute it freely. Source code can be browsed and copied from the project page (see Git repository).

License 	: MIT
Project page	: http://sourceforge.net/projects/glip-lib/
Help page 	: http://glip-lib.sourceforge.net/

Contributors : 
Ronan Kerviche (ronan dot kerviche at free dot fr)
Corentin Derbois