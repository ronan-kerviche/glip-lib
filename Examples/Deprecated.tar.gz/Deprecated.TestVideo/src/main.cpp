#include "VideoPlayer.hpp"

int main(int argc, char** argv)
{
	VideoModApplication app(argc, argv);
	return app.exec();
}
